<?php
echo '<br /><br /><br /><center>';
echo '<form method = "POST" action = "index.php?menu=8">';
echo 'cena: <input name="cena" type="text" /><br /><br />';
echo 'nazov: <input name="nazov" type="text" /><br /><br />';
echo '<input type="submit" name="submit" value="Odoslat"/>';
echo '</form></center>';
?>