<?php
$localhost = "localhost";
$user = "root";
$password = "";
$db = "zaklad"; 
?>
