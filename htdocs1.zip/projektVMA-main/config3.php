<?php
$localhost3 = "25.32.93.123";
$user3 = "root";
$password3 = "";
$db3 = "zaklad"; 
?>
