<?php
$localhost2 = "25.52.107.171";
$user2 = "root";
$password2 = "";
$db2 = "zaklad"; 
?>
