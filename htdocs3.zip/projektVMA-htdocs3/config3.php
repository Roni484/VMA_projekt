<?php
$localhost3 = "localhost";
$user3 = "root";
$password3 = "";
$db3 = "zaklad"; 
?>
