
<b>

<font color="#000080" face="Verdana" size="2"><br><br><br>
<!--<p><a href="index.php?menu=1"> <font color="#000080"> prihlásenie </font> </a></p>
<p><a href="index.php?menu=2"> <font color="#000080"> registrácia </font> </a></p>
<p><a href="index.php?menu=3"> <font color="#000080"> výpis </font> </a></p>
<p><a href="index.php?menu=5"> <font color="#000080"> vyhľadávanie </font> </a></p>-->
<p><a href="index.php?menu=7"> <font color="#000080"> pridanie tovaru </font> </a></p>
<p><a href="index.php?menu=8"> <font color="#000080"> vypis tovarov </font> </a></p>
<p><a href="index.php?menu=9"> <font color="#000080"> vyhladanie tovaru </font> </a></p>
<p><a href="index.php?menu=11"> <font color="#000080"> synchronizácia </font> </a></p>


<br>


