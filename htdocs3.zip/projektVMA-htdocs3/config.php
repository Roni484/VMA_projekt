<?php
$localhost = "25.29.175.74";
$user = "root";
$password = "";
$db = "zaklad"; 
?>
